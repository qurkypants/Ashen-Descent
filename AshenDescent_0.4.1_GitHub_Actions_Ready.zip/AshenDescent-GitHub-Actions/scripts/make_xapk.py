#!/usr/bin/env python3
"""Package the GitHub Actions-built APK into an optional one-base XAPK."""
from pathlib import Path
import json
import shutil
import zipfile

BASE = Path(__file__).resolve().parent.parent
APK = BASE / "app/build/outputs/apk/debug/app-debug.apk"
ICON = BASE / "icon.png"
OUTPUT = BASE / "output"

if not APK.is_file() or APK.stat().st_size < 10000:
    raise SystemExit("Missing or unexpectedly small APK. Did :app:assembleDebug succeed?")
if not ICON.is_file():
    raise SystemExit("Missing icon.png")
OUTPUT.mkdir(exist_ok=True)
public_apk = OUTPUT / "AshenDescent_Alpha_0.4.1.apk"
public_xapk = OUTPUT / "AshenDescent_Alpha_0.4.1.xapk"
shutil.copy2(APK, public_apk)

apk_inside_xapk = "com.ashen.descent.apk"
manifest = {
    "xapk_version": "2",
    "package_name": "com.ashen.descent",
    "name": "Ashen Descent",
    "version_code": "9",
    "version_name": "0.4.1-alpha",
    "min_sdk_version": "24",
    "target_sdk_version": "28",
    "permissions": [],
    "total_size": public_apk.stat().st_size,
    "icon": "icon.png",
    "split_apks": [{"id": "base", "file": apk_inside_xapk}],
}
with zipfile.ZipFile(public_xapk, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as zf:
    zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    zf.write(ICON, "icon.png")
    zf.write(public_apk, apk_inside_xapk)

with zipfile.ZipFile(public_xapk) as zf:
    assert zf.testzip() is None
    assert set(zf.namelist()) == {"manifest.json", "icon.png", apk_inside_xapk}

print("APK:", public_apk)
print("XAPK:", public_xapk)
