package com.ashen.descent;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Context;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private WebView gameView;

    public static class StorageBridge {
        private final SharedPreferences preferences;

        StorageBridge(Context context) {
            preferences = context.getSharedPreferences("ashen_descent_v01", Context.MODE_PRIVATE);
        }

        @JavascriptInterface
        public String loadState() {
            return preferences.getString("save", "");
        }

        @JavascriptInterface
        public void saveState(String json) {
            // Single-player offline prototype; no network permissions or remote pages.
            preferences.edit().putString("save", json).apply();
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        gameView = new WebView(this);
        gameView.setWebViewClient(new WebViewClient());
        gameView.setWebChromeClient(new WebChromeClient());
        gameView.getSettings().setJavaScriptEnabled(true);
        gameView.getSettings().setDomStorageEnabled(true);
        gameView.getSettings().setAllowFileAccess(true);
        gameView.setFocusableInTouchMode(true);
        gameView.requestFocus();
        gameView.addJavascriptInterface(new StorageBridge(getApplicationContext()), "AndroidStorage");
        setContentView(gameView);
        gameView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onPause() {
        // Stop counting active playtime when the app moves to the background.
        if (gameView != null) {
            gameView.evaluateJavascript("window.AshenHostPause && window.AshenHostPause()", null);
            gameView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) {
            gameView.onResume();
            gameView.evaluateJavascript("window.AshenHostResume && window.AshenHostResume()", null);
        }
    }

    @Override
    protected void onDestroy() {
        if (gameView != null) {
            gameView.removeJavascriptInterface("AndroidStorage");
            gameView.destroy();
        }
        super.onDestroy();
    }
}
