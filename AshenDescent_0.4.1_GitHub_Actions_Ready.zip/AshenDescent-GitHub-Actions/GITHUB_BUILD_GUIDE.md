# Ashen Descent Alpha 0.4.1 — GitHub Actions Android Builds

This contains the real Ashen Descent 0.4.1 Android project from the chat,
with a GitHub Actions workflow to build a **debug APK** and package a **single-base XAPK**.

## Build on GitHub (no PC needed once the repository is uploaded)

1. Make a GitHub repository (private is fine).
2. Upload the **extracted contents** of this folder to the repository. Do not simply upload the ZIP as a single file. Preserve `.github/workflows/build-android.yml` and the `app/` directory.
3. Open your GitHub repo > **Actions** > **Build Ashen Descent (APK + XAPK)**.
4. Click **Run workflow** (or push the files to `main` to start a run automatically).
5. Wait for the run to finish with a green check.
6. Open the run and look under **Artifacts**; download **AshenDescent-0.4.1-Android**.
7. Extract that artifact ZIP on your Android phone. You'll get `.apk` and `.xapk` files.
8. Install the APK directly (simplest). Installing the XAPK requires a compatible XAPK installer.

The repository will need Actions enabled. The first run downloads SDK 35 and Gradle dependencies. No physical Android device is required to compile the APK.

## Important about app updates and saves

This makes an **Android debug-signed APK**. GitHub-hosted runners may create a *different debug signing key each run*, so subsequent builds might not install as upgrades. For reliable future upgrades, configure a persistent, privately stored release-signing keystore in GitHub Actions secrets. Do not publish your signing key in the repo. Uninstalling an installed app can erase its locally saved vault and tracker.

Browser HTML saves do **not** automatically transfer to Android WebView data, even with the same game version.

## Project technical notes

- Android application ID: `com.ashen.descent`
- Version: `0.4.1-alpha`, versionCode `9`
- Android Gradle Plugin: `8.7.3`
- JDK: `17`
- Gradle: `8.10.2` (installed by the workflow because the project has no Gradle wrapper)
- Android SDK: `35`
- Android minimum SDK: `24`
- Main game file: `app/src/main/assets/index.html`
- Workflow: `.github/workflows/build-android.yml`
- XAPK packager: `scripts/make_xapk.py`

The XAPK wraps the same APK, with a metadata manifest and icon. It has no split APKs or extra assets. A normal APK is more straightforward to install for this particular game.

### Limits

The workflow configuration has been inspected, and the XAPK Python packaging code can be tested here, but **a GitHub Actions run has not been executed on your account**, so the final Android compilation has not yet been verified. If a cloud build fails, send the Actions error and it can be fixed in the next revision.
