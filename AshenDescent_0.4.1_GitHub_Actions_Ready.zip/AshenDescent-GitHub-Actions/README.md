# ASHEN DESCENT — ALPHA 0.4.1

Single-player offline permadeath dungeon crawler. The HTML file is directly playable in a browser; the ZIP contains Android Studio source, **not** a compiled APK.

## New: Kimmish — the gem thief

- In **40% of ordinary room encounters**, the normal enemy is replaced by **Kimmish**. Scheduled bosses (including Hyper Bosses and Floor Masters) are never replaced.
- Kimmish has lower HP and base damage than ordinary enemies, and any attack that lands deals at most **3 HP**.
- On every **successful, non-dodged** attack, Kimmish has an independent **4% chance** to steal **one gem** from your carried gem pouch. If the pouch is empty, he steals nothing. A successful SWFT dodge prevents theft. Gems stolen in an encounter are permanently lost; vaulted equipment and your permanent coin balance are unaffected.
- He has his own small pixel art and occasional dialogue. Steals are announced in the combat narration, and the per-run total is saved.

## Permanent achievements

Achievements are shown in the **About** tab with locked/unlocked states and an unlock notification:

1. **It goes deeper?** — Reach Floor 10.
2. **The short stroll** — Enter Room 15 of any floor.
3. **Gettin bossy** — Defeat your first boss, including a scheduled, Hyper, Floor Master, or Grimble boss.

Achievements are stored under `meta.achievements`, not on the character. They **survive permadeath and new runs**. Old runs can retroactively unlock achievements when their recorded floor/room progress is enough to demonstrate that they qualified. Progress inferred from previous runs is marked as historical rather than receiving a made-up date. Localized achievement labels are included for Spanish (Mexico).

## Unchanged core systems

Enemy/equipment scaling ×1.17 per cumulative room, ×1.55 per floor; Grimble merchants; gem drop chance 60%; 8 equipment rarities; Room 50/100/150 Hyper Bosses and Room 200 Floor Master; Bunker/vault; 3 accessory slots; Golden Cross revival; permanent coins; loot tracker; scientific notation; dark/light theme; Mexican Spanish menus; browser-active playtime counter.

## Saving and compatibility

Save key: `ashen_descent_alpha_01`. Android package/application ID: `com.ashen.descent`. WebView SharedPreferences ID: `ashen_descent_v01`. Android `versionCode 9`, `versionName 0.4.1-alpha`.

Older characters, items, permanent vaults, gems, coins, loot tracker, and settings are not rewritten. Existing saves migrate in-place to add permanent achievement data and theft/boss counters. Android Studio upgrades must use the same signing key as the installed APK. Chrome's local HTML file storage may be isolated per downloaded file, so preserve your old HTML until you have verified that your new file can access the same save.

## Build Android APK

Open this project folder in Android Studio with JDK 17 and Android SDK 35. Sync Gradle, then Build → Build APK(s). The ZIP includes no Gradle wrapper or precompiled APK. A native APK was not built/tested in this container.

## Tested

`node --check` on the JavaScript, headless Chromium interaction tests using the standalone self-contained HTML: randomized Kimmish spawn rate (~40% over 10,000 encounters), boss preservation, 4% theft path with gems, no theft when pouch empty or attack dodged, Kimmish 1–3 HP connected-hit damage cap, historical achievement recovery, fresh Room 15 and Floor 10 unlocks, boss kill unlock, reload persistence, permanent achievement survival after starting a new character, and Mexican-Spanish achievement text.
